const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database("hariharan_automobiles.db");

db.exec(`
  CREATE TABLE IF NOT EXISTS enquiries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    vehicle TEXT,
    service TEXT NOT NULL,
    preferred_date TEXT,
    message TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/bookings", (req, res) => {
  const { name, phone, vehicle, service, preferred_date, message } = req.body;
  if (!name || !phone || !service) {
    return res.status(400).json({ ok: false, message: "Name, phone and service are required." });
  }

  const stmt = db.prepare(`
    INSERT INTO enquiries (name, phone, vehicle, service, preferred_date, message)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  const result = stmt.run(
    String(name).trim(),
    String(phone).trim(),
    String(vehicle || "").trim(),
    String(service).trim(),
    String(preferred_date || "").trim(),
    String(message || "").trim()
  );

  res.json({ ok: true, id: result.lastInsertRowid });
});

app.get("/api/bookings", (req, res) => {
  const bookings = db.prepare("SELECT * FROM enquiries ORDER BY id DESC").all();
  res.json(bookings);
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"));
});

app.listen(PORT, () => {
  console.log(`Hariharan Automobiles running at http://localhost:${PORT}`);
});
