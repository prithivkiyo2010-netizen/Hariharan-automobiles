# Hariharan Automobiles Website

## Included
- Responsive customer website
- Painting, tinkering/dent repair and mechanical services
- Call + WhatsApp buttons
- Neelankarai location link
- Online service enquiry form
- SQLite database for enquiries
- Simple admin enquiry page at `/admin`
- Starter workshop images, replaceable with real workshop photos

## Run locally
1. Install Node.js 18+.
2. Open this project folder in a terminal.
3. Run:
   npm install
   npm start
4. Open http://localhost:3000
5. Admin enquiries: http://localhost:3000/admin

## Before publishing
- Replace starter gallery images with the workshop's own photos.
- Add the exact street address.
- Add business hours.
- Add a proper admin login before making `/admin` public.
- For production, use HTTPS and a hosted database or secure server storage.
